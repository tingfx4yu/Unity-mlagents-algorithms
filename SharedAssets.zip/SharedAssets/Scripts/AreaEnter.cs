﻿using UnityEngine;

namespace MLAgents
{
    /// <summary>
    /// This class contains logic for locomotion agents with joints which might make contact with a target.
    /// By attaching this as a component to those joints, their contact with the ground can be used as
    /// an observation for that agent.
    /// </summary>
    [DisallowMultipleComponent]
    public class AreaEnter : MonoBehaviour
    {
        [Header("Detect Targets")] public bool areaEnter1;
        public bool areaEnter2;
        private const string k_Target = "area";
        private const string kk_Target = "area1"; // Tag on target object.
        //private const string s_Target = "steps";

        /// <summary>
        /// Check for collision with a target.
        /// </summary>
        void OnTriggerEnter(Collider col)
        {
            if (col.transform.CompareTag(k_Target))
            {
                areaEnter1 = true;
 
            }
            if (col.transform.CompareTag(kk_Target))
            {
                areaEnter2 = true;
 
            }
        }

        /// <summary>
        /// Check for end of ground collision and reset flag appropriately.
        /// </summary>
        void OnTriggerExit(Collider other)
        {
            if (other.transform.CompareTag(k_Target))
            {
                areaEnter1 = false;
            }
            if (other.transform.CompareTag(kk_Target))
            {
                areaEnter2 = false;
            }
        }
    }
}
